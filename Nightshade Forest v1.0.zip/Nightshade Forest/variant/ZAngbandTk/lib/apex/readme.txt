If you want to compete against my high scores (no wins yet),
rename z_scores.raw to scores.raw
        --ty
